# mapofafrica

This plugin uses the shortcode [map_of_africa] to display a map of African on a WordPress page. 

<img width="646" alt="Screenshot MapOfAfrica" src="https://github.com/user-attachments/assets/f2dcfcee-720c-4340-a65d-366cfcaf1c0c">
